# 光流估计块匹配法FPGA实现项目

## 项目概述

本项目在Xilinx Spartan-7 FPGA（Boolean板卡，型号：xc7s50csga324-1）上实现了基于块匹配法的光流估计算法。光流估计是计算机视觉中的重要技术，用于检测图像序列中物体的运动。

### 主要特性

- **算法**: 块匹配法光流估计
- **目标设备**: Xilinx Spartan-7 xc7s50csga324-1
- **图像分辨率**: 640×480像素（可配置）
- **块大小**: 16×16像素
- **搜索范围**: ±8像素
- **数据位宽**: 8位灰度图像
- **实时处理**: 支持视频流实时处理

## 算法原理

### 块匹配法光流估计

块匹配法是一种经典的光流估计算法，其基本原理如下：

1. **图像分块**: 将当前帧图像分割成若干个固定大小的块（本项目使用16×16像素块）
2. **搜索匹配**: 在前一帧图像的搜索窗口内寻找与当前块最相似的块
3. **相似度计算**: 使用SAD（Sum of Absolute Differences）算法计算块之间的相似度
4. **光流向量**: 最佳匹配位置与当前块位置的差值即为光流向量

### SAD算法

SAD（绝对差值和）计算公式：

```
SAD(i,j) = Σ Σ |I₁(x+i, y+j) - I₀(x, y)|
           x y
```

其中：
- I₀(x,y) 是当前帧的像素值
- I₁(x+i, y+j) 是前一帧的像素值
- (i,j) 是搜索偏移量

## 项目结构

```
optical_flow_fpga/
├── src/                          # 源代码目录
│   ├── optical_flow_top.v        # 顶层模块
│   ├── frame_buffer.v             # 帧缓存模块
│   ├── block_matcher.v            # 块匹配模块
│   ├── block_extractor.v          # 块提取模块
│   └── optical_flow_controller.v  # 光流控制器
├── constraints/                   # 约束文件目录
│   └── boolean_board.xdc          # Boolean板卡约束文件
├── sim/                          # 仿真文件目录
│   └── optical_flow_tb.v          # 测试台文件
├── scripts/                      # 脚本目录
│   ├── create_project.tcl         # 项目创建脚本
│   └── build_project.tcl          # 项目构建脚本
├── output/                       # 输出文件目录
└── README.md                     # 本文档
```

## 模块说明

### 1. optical_flow_top.v
顶层模块，包含：
- 时钟管理
- 图像输入接口
- 光流输出接口
- 主控制状态机

### 2. frame_buffer.v
双帧缓存模块，功能：
- 存储当前帧和前一帧图像
- 支持并行读写操作
- 自动帧切换管理

### 3. block_matcher.v
SAD计算模块，实现：
- 16×16块的SAD计算
- 流水线处理
- 结果输出控制

### 4. block_extractor.v
块提取模块，负责：
- 从帧缓存提取指定位置的图像块
- 边界处理
- 数据格式转换

### 5. optical_flow_controller.v
光流计算控制器，协调：
- 块匹配过程
- 搜索策略
- 最优匹配选择

## 硬件连接

### Boolean板卡引脚分配

#### 时钟和复位
- **系统时钟 (clk)**: N11 - 100MHz输入时钟
- **复位信号 (rst_n)**: G4 - 低电平有效复位

#### 图像输入接口
- **像素数据 (pixel_in[7:0])**: A14-B11 - 8位灰度像素数据
- **像素有效 (pixel_valid)**: C14 - 像素数据有效信号
- **帧开始 (frame_start)**: C13 - 帧开始信号
- **行开始 (line_start)**: C12 - 行开始信号

#### 光流输出接口
- **X方向光流 (flow_x[15:0])**: E14-H11 - 16位有符号X方向光流
- **Y方向光流 (flow_y[15:0])**: J14-M11 - 16位有符号Y方向光流
- **光流有效 (flow_valid)**: P14 - 光流数据有效信号

#### 状态指示
- **处理中 (processing)**: P13 - 处理状态指示
- **调试状态 (debug_state[7:0])**: R14-T11 - 8位调试状态

## 使用方法

### 1. 环境准备

确保安装以下软件：
- Xilinx Vivado 2020.1或更高版本
- Boolean板卡驱动程序

### 2. 项目创建

#### 方法一：使用TCL脚本（推荐）

```bash
# 打开Vivado TCL Console
# 执行项目创建脚本
source e:/vivado_projects/optical_flow_fpga/scripts/create_project.tcl
```

#### 方法二：手动创建

1. 打开Vivado
2. 创建新项目：
   - 项目名称：optical_flow_fpga
   - 项目位置：e:/vivado_projects/optical_flow_fpga
   - 器件选择：xc7s50csga324-1
3. 添加源文件（src目录下的所有.v文件）
4. 添加约束文件（constraints/boolean_board.xdc）
5. 添加仿真文件（sim/optical_flow_tb.v）
6. 创建时钟向导IP核（clk_wiz_0）

### 3. 仿真验证

```tcl
# 在Vivado TCL Console中执行
launch_simulation
run all
```

仿真将验证：
- 图像数据输入处理
- 块匹配算法正确性
- 光流向量输出

### 4. 综合与实现

#### 使用构建脚本（推荐）

```tcl
# 执行完整构建流程
source e:/vivado_projects/optical_flow_fpga/scripts/build_project.tcl
```

#### 手动构建

1. **综合**：
   ```tcl
   launch_runs synth_1 -jobs 4
   wait_on_run synth_1
   ```

2. **实现**：
   ```tcl
   launch_runs impl_1 -jobs 4
   wait_on_run impl_1
   ```

3. **生成比特流**：
   ```tcl
   launch_runs impl_1 -to_step write_bitstream -jobs 4
   wait_on_run impl_1
   ```

### 5. 硬件部署

1. **连接Boolean板卡**到计算机
2. **打开Hardware Manager**：
   ```tcl
   open_hw_manager
   connect_hw_server
   open_hw_target
   ```

3. **下载比特流**：
   ```tcl
   set_property PROGRAM.FILE {e:/vivado_projects/optical_flow_fpga/output/optical_flow_top.bit} [get_hw_devices xc7s50_0]
   program_hw_devices [get_hw_devices xc7s50_0]
   ```

### 6. 系统集成

#### 图像输入连接

可以通过以下方式提供图像输入：

1. **摄像头模块**：连接支持并行输出的摄像头
2. **图像生成器**：使用FPGA内部生成测试图像
3. **外部处理器**：通过SPI/I2C接口传输图像数据

#### 输出数据处理

光流向量输出可以：

1. **连接到LED**：显示运动方向
2. **串口输出**：发送到上位机处理
3. **存储到内存**：用于后续分析

## 性能指标

### 资源利用率（预估）

| 资源类型 | 使用量 | 总量 | 利用率 |
|----------|--------|------|--------|
| LUT      | ~15000 | 32600| ~46%   |
| FF       | ~8000  | 65200| ~12%   |
| BRAM     | ~25    | 75   | ~33%   |
| DSP      | ~10    | 120  | ~8%    |

### 时序性能

- **最大工作频率**: ~100MHz
- **处理延迟**: ~1000个时钟周期/块
- **吞吐率**: ~100K块/秒

### 功耗估算

- **静态功耗**: ~0.5W
- **动态功耗**: ~1.5W
- **总功耗**: ~2.0W

## 调试与优化

### 1. 仿真调试

- 使用测试台验证算法正确性
- 检查时序关系
- 验证边界条件处理

### 2. 硬件调试

- 使用ILA（Integrated Logic Analyzer）监控内部信号
- 检查时钟域交叉
- 验证I/O时序

### 3. 性能优化

#### 提高处理速度
- 增加并行处理单元
- 优化流水线设计
- 使用更高效的存储结构

#### 降低资源消耗
- 优化数据位宽
- 共享计算资源
- 使用更紧凑的存储方案

## 扩展功能

### 1. 多尺度光流
- 实现图像金字塔
- 支持不同分辨率处理

### 2. 亚像素精度
- 插值算法实现
- 提高光流精度

### 3. 实时显示
- VGA/HDMI输出接口
- 光流可视化

## 常见问题

### Q1: 综合时出现时序违例
**A**: 检查时钟约束，适当降低工作频率或优化关键路径。

### Q2: 仿真结果不正确
**A**: 检查测试数据格式，验证算法实现逻辑。

### Q3: 资源利用率过高
**A**: 优化数据位宽，减少并行度或使用更高效的算法。

### Q4: 功耗过高
**A**: 启用时钟门控，优化数据路径，降低工作频率。

## 技术支持

如有技术问题，请检查：
1. Vivado版本兼容性
2. 约束文件正确性
3. 器件型号匹配
4. 引脚分配冲突

## 版本历史

- **v1.0** (2024-01): 初始版本，基本光流估计功能
- 后续版本将添加更多优化和功能扩展

## 许可证

本项目采用MIT许可证，详见LICENSE文件。

---

**注意**: 本项目仅供学习和研究使用，商业应用请确保符合相关法规要求。